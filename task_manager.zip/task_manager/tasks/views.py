from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Task, User
from .serializers import TaskSerializer, AssignTaskSerializer


class CreateTaskView(generics.CreateAPIView):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer


def post(request):
    serializer = AssignTaskSerializer(data=request.data)
    if serializer.is_valid():
        task = Task.objects.get(id=serializer.validated_data['task_id'])
        users = User.objects.filter(id__in=serializer.validated_data['user_ids'])
        task.assigned_users.set(users)
        return Response({'message': 'Task assigned successfully'}, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AssignTaskView(APIView):
    pass


class UserTasksView(generics.ListAPIView):
    serializer_class = TaskSerializer

    def get_queryset(self):
        user_id = self.kwargs['user_id']
        return Task.objects.filter(assigned_users__id=user_id)
